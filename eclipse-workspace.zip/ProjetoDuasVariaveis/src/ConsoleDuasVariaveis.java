
public class ConsoleDuasVariaveis {

	public static void main(String[] args) {
		System.out.println("***************************");
		System.out.println("APP DE SOMA DE DOIS VALORES");
		System.out.println("***************************");
		
		int v1 = 65;
		int v2 = 35;
		int resultado = v1 + v2;
		
		System.out.println("Valor 1: " + v1);
		System.out.println("Valor 2: " + v2);
		
		System.out.println("A soma � " + resultado);

	}

}
